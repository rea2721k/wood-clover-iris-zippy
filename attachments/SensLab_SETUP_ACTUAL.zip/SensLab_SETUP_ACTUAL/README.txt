SensLab Setup - actual binary

This package contains real Windows installer executables:
  SensLab_Setup.exe       x64 installer
  SensLab_Setup_x86.exe   x86 installer

The installer is self-contained: it embeds the SensLab x64/x86 application payload and the SensLab ICO, then:
- installs to %LOCALAPPDATA%\\Programs\\SensLab
- creates Desktop and Start Menu shortcuts
- writes HKCU uninstall information
- creates Uninstall.exe in the install directory
- supports --uninstall
- offers to launch SensLab after installation

IMPORTANT:
The embedded application is the last compiled SensLab Real Polling build available in this Linux build environment. The newer C++ PRO 1.2 source exists, but no Windows MSVC/WebView2 build was available here to compile that source into a verified EXE. This prevents falsely claiming that this installer contains the unbuilt C++ PRO 1.2 binary.
