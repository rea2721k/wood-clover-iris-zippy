package main

import (
    _ "embed"
    "encoding/base64"
    "fmt"
    "os"
    "os/exec"
    "path/filepath"
    "runtime"
    "syscall"
    "time"
    "unsafe"
)

//go:embed SensLab_x64_payload.exe
var payloadX64 []byte

//go:embed SensLab_x86_payload.exe
var payloadX86 []byte

//go:embed SensLab.ico
var iconData []byte

var (
    user32   = syscall.NewLazyDLL("user32.dll")
    shell32  = syscall.NewLazyDLL("shell32.dll")
    msgBox   = user32.NewProc("MessageBoxW")
)

const (
    mbOK                = 0x00000000
    mbOKCancel          = 0x00000001
    mbYesNo             = 0x00000004
    mbIconError         = 0x00000010
    mbIconQuestion      = 0x00000020
    mbIconInformation   = 0x00000040
    mbTopMost            = 0x00040000
    idOK                = 1
    idCancel             = 2
    idYes                = 6
    idNo                 = 7
)

func wide(s string) *uint16 {
    p, _ := syscall.UTF16PtrFromString(s)
    return p
}

func message(title, text string, flags uintptr) int {
    r, _, _ := msgBox.Call(0, uintptr(unsafe.Pointer(wide(text))), uintptr(unsafe.Pointer(wide(title))), flags)
    return int(r)
}


func runPowerShell(script string) error {
    // PowerShell -EncodedCommand expects UTF-16LE.
    utf16 := make([]byte, 0, len(script)*2)
    for _, r := range script {
        u := uint16(r)
        utf16 = append(utf16, byte(u), byte(u>>8))
    }
    enc := base64.StdEncoding.EncodeToString(utf16)
    cmd := exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc)
    cmd.Stdout = nil
    cmd.Stderr = nil
    return cmd.Run()
}

func installDir() string {
    base := os.Getenv("LOCALAPPDATA")
    if base == "" {
        if h, err := os.UserHomeDir(); err == nil { base = filepath.Join(h, "AppData", "Local") }
    }
    return filepath.Join(base, "Programs", "SensLab")
}

func main() {
    if len(os.Args) > 1 && os.Args[1] == "--uninstall" {
        uninstall()
        return
    }

    dir := installDir()
    if message("SensLab Setup", "SensLab bilgisayarınıza kurulacak.\n\nKurulum klasörü:\n"+dir+"\n\nDevam edilsin mi?", mbYesNo|mbIconQuestion|mbTopMost) != idYes {
        return
    }

    if err := os.MkdirAll(dir, 0o755); err != nil {
        message("SensLab Setup", "Kurulum klasörü oluşturulamadı:\n"+err.Error(), mbOK|mbIconError|mbTopMost)
        return
    }

    exeName := "SensLab.exe"
    var payload []byte
    if runtime.GOARCH == "amd64" {
        payload = payloadX64
    } else {
        payload = payloadX86
    }
    target := filepath.Join(dir, exeName)
    if err := os.WriteFile(target, payload, 0o755); err != nil {
        message("SensLab Setup", "SensLab.exe yazılamadı:\n"+err.Error(), mbOK|mbIconError|mbTopMost)
        return
    }
    iconPath := filepath.Join(dir, "SensLab.ico")
    if err := os.WriteFile(iconPath, iconData, 0o644); err != nil {
        message("SensLab Setup", "Logo çıkarılamadı:\n"+err.Error(), mbOK|mbIconError|mbTopMost)
        return
    }

    // The same installer binary becomes the uninstaller.
    self, err := os.Executable()
    if err != nil {
        message("SensLab Setup", "Kurulum dosyası yolu alınamadı:\n"+err.Error(), mbOK|mbIconError|mbTopMost)
        return
    }
    uninstaller := filepath.Join(dir, "Uninstall.exe")
    if err := copyFile(self, uninstaller); err != nil {
        message("SensLab Setup", "Uninstaller oluşturulamadı:\n"+err.Error(), mbOK|mbIconError|mbTopMost)
        return
    }

    desktop := filepath.Join(os.Getenv("USERPROFILE"), "Desktop", "SensLab.lnk")
    start := filepath.Join(os.Getenv("APPDATA"), "Microsoft", "Windows", "Start Menu", "Programs", "SensLab.lnk")
    script := fmt.Sprintf(`$ErrorActionPreference='Stop'
$ws=New-Object -ComObject WScript.Shell
$s=$ws.CreateShortcut('%s');$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Save()
$s=$ws.CreateShortcut('%s');$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Save()
$u='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SensLab'
New-Item -Path $u -Force | Out-Null
New-ItemProperty -Path $u -Name DisplayName -Value 'SensLab' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $u -Name DisplayVersion -Value '1.2.0' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $u -Name Publisher -Value 'SensLab' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $u -Name InstallLocation -Value '%s' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $u -Name DisplayIcon -Value '%s' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $u -Name UninstallString -Value '"%s" --uninstall' -PropertyType String -Force | Out-Null
`, desktop, target, dir, iconPath, start, target, dir, iconPath, dir, iconPath, uninstaller)

    if err := runPowerShell(script); err != nil {
        message("SensLab Setup", "Kısayollar/Windows kaldırma kaydı oluşturulurken hata oluştu:\n"+err.Error(), mbOK|mbIconError|mbTopMost)
        return
    }

    if message("SensLab Setup", "Kurulum tamamlandı.\n\nMasaüstü ve Başlat Menüsü kısayolları oluşturuldu.\nWindows Ayarları → Uygulamalar → Yüklü uygulamalar bölümünden SensLab kaldırılabilir.\n\nSensLab şimdi başlatılsın mı?", mbYesNo|mbIconInformation|mbTopMost) == idYes {
        _ = exec.Command(target).Start()
    }
}

func uninstall() {
    dir := installDir()
    if message("SensLab Kaldırma", "SensLab bilgisayarınızdan kaldırılacak.\n\nDevam edilsin mi?", mbYesNo|mbIconQuestion|mbTopMost) != idYes {
        return
    }
    desktop := filepath.Join(os.Getenv("USERPROFILE"), "Desktop", "SensLab.lnk")
    start := filepath.Join(os.Getenv("APPDATA"), "Microsoft", "Windows", "Start Menu", "Programs", "SensLab.lnk")
    script := fmt.Sprintf(`$ErrorActionPreference='SilentlyContinue'
Remove-Item '%s' -Force
Remove-Item '%s' -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SensLab' -Recurse -Force
Start-Process -FilePath cmd.exe -ArgumentList '/c','ping 127.0.0.1 -n 3 >nul & rmdir /s /q "%s"' -WindowStyle Hidden
`, desktop, start, dir)
    _ = runPowerShell(script)
    message("SensLab Kaldırma", "SensLab kaldırılıyor.\nKurulum klasörü kısa süre içinde silinecek.", mbOK|mbIconInformation|mbTopMost)
    time.Sleep(250)
}

func copyFile(src, dst string) error {
    b, err := os.ReadFile(src)
    if err != nil { return err }
    if err := os.WriteFile(dst, b, 0o755); err != nil { return err }
    return nil
}

var _ = shell32
